<?php
namespace App\Providers;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Gate;
use App\Models\PaymentMethod;
use App\Policies\PaymentMethodPolicy;
use App\Models\User;
use App\Policies\UserPolicy;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void {}
    public function boot(): void
    {
        Gate::policy(PaymentMethod::class, PaymentMethodPolicy::class);
        Gate::policy(User::class, UserPolicy::class);
    }
}
